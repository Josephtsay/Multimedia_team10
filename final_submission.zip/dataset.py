import os
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as transforms

# Final label spec: 0=N/A, 1=fist, 2=like, 3=ok, 4=one, 5=palm
GESTURE_CLASSES = ['fist', 'like', 'ok', 'one', 'palm']
CLASS_TO_IDX = {name: i + 1 for i, name in enumerate(GESTURE_CLASSES)}  # 1-based
NA_IDX = 0
NA_CLASS = 'na'

TRAIN_TRANSFORM = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2),
    transforms.RandomRotation(15),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

VAL_TRANSFORM = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])


class GestureImageDataset(Dataset):
    """Image-only dataset for gesture classification (Step 1).

    root_dir: path like baseline_dataset_zip/val/val
    include_na: if True, load na/ images as class index 5 (for 6-class training)
    """

    def __init__(self, root_dir, transform=None, include_na=False):
        self.transform = transform
        self.samples = []  # list of (img_path, label)

        for cls_name, cls_idx in CLASS_TO_IDX.items():
            img_dir = os.path.join(root_dir, cls_name, 'crop_image')
            if not os.path.isdir(img_dir):
                continue
            for fname in sorted(os.listdir(img_dir)):
                if fname.lower().endswith('.png'):
                    self.samples.append((os.path.join(img_dir, fname), cls_idx))

        if include_na:
            na_dir = os.path.join(root_dir, NA_CLASS, 'crop_image')
            if os.path.isdir(na_dir):
                for fname in sorted(os.listdir(na_dir)):
                    if fname.lower().endswith('.png'):
                        self.samples.append((os.path.join(na_dir, fname), NA_IDX))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        img = Image.open(img_path).convert('RGB')
        if self.transform:
            img = self.transform(img)
        return img, label


# ── Landmark preprocessing ────────────────────────────────────────────────────

# wrist(0) → finger-tip chains for computing joint-angle features
_FINGER_CHAINS = [
    [0, 1, 2, 3, 4],     # wrist → thumb
    [0, 5, 6, 7, 8],     # wrist → index
    [0, 9, 10, 11, 12],  # wrist → middle
    [0, 13, 14, 15, 16], # wrist → ring
    [0, 17, 18, 19, 20], # wrist → pinky
]
# 42 normalised coords + 15 angle cosines + 9 distance features
LANDMARK_FEATURE_DIM = 42 + 15 + 9  # 66


def preprocess_landmarks(lm_flat: np.ndarray, augment: bool = False) -> np.ndarray:
    """
    lm_flat: (42,) crop-relative x,y landmarks from MediaPipe.
    Returns: (66,) float32 — wrist-normalised coords + 15 angle cosines + 9 distances.
    """
    lm = lm_flat.reshape(21, 2).copy()

    if augment:
        if np.random.rand() < 0.5:
            lm[:, 0] = 1.0 - lm[:, 0]  # horizontal flip
        lm += np.random.normal(0, 0.01, lm.shape).astype(np.float32)

    # centre on wrist (landmark 0) and normalise by wrist→middle-MCP distance
    wrist = lm[0].copy()
    lm -= wrist
    scale = float(np.linalg.norm(lm[9])) + 1e-6
    lm /= scale

    # joint-angle cosines along each finger chain
    angle_feats = []
    for chain in _FINGER_CHAINS:
        for i in range(1, len(chain) - 1):
            v1 = lm[chain[i - 1]] - lm[chain[i]]
            v2 = lm[chain[i + 1]] - lm[chain[i]]
            cos_a = np.dot(v1, v2) / (
                np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-6
            )
            angle_feats.append(float(cos_a))

    # fingertip-to-wrist distances: proxy for "is each finger extended?"
    tip_ids = [4, 8, 12, 16, 20]
    dist_feats = [float(np.linalg.norm(lm[t])) for t in tip_ids]

    # thumb-tip to each fingertip distance: key for "ok" (thumb≈index) detection
    for t in [8, 12, 16, 20]:
        dist_feats.append(float(np.linalg.norm(lm[4] - lm[t])))

    return np.concatenate([lm.flatten(), angle_feats, dist_feats]).astype(np.float32)


class GestureLandmarkDataset(Dataset):
    """Landmark-only dataset loaded from pre-computed .npz files.

    npz_path: e.g. landmarks_npz/train_landmarks.npz
    Keys expected: 'X' (N, 42) float32,  'y' (N,) int64
    Labels: 0=N/A, 1=fist, 2=like, 3=ok, 4=one, 5=palm

    max_na_samples: cap the number of N/A training samples so the dataset is
    class-balanced. Set to None to use all N/A samples (default).
    """

    def __init__(self, npz_path: str, augment: bool = False,
                 max_na_samples: int | None = None):
        data = np.load(npz_path)
        X, y = data['X'], data['y']

        if max_na_samples is not None:
            na_idx    = np.where(y == 0)[0]
            other_idx = np.where(y != 0)[0]
            if len(na_idx) > max_na_samples:
                rng = np.random.default_rng(seed=42)
                na_idx = rng.choice(na_idx, max_na_samples, replace=False)
            keep = np.concatenate([na_idx, other_idx])
            rng2 = np.random.default_rng(seed=0)
            rng2.shuffle(keep)
            X, y = X[keep], y[keep]

        self.X = X
        self.y = y
        self.augment = augment

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        feat = preprocess_landmarks(self.X[idx], augment=self.augment)
        return torch.tensor(feat, dtype=torch.float32), int(self.y[idx])


# ── Dual-branch dataset (image + landmarks) ───────────────────────────────────

# Image-only transforms for the dual dataset.
# Horizontal flip is handled MANUALLY inside __getitem__ so it can be
# synchronised with the corresponding landmark x-flip.
_DUAL_IMG_JITTER = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.3, hue=0.1),
    transforms.RandomRotation(10),
    transforms.RandomGrayscale(p=0.05),
    transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 1.5)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

_DUAL_IMG_VAL = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])


class GestureDualDataset(Dataset):
    """Dual-branch dataset: returns (image_tensor, landmark_features, label).

    img_root : e.g. 'baseline_dataset_zip/val/val'
    npz_path : e.g. 'landmarks_npz/val_landmarks.npz'

    The npz was pre-computed from the same images in img_root, sorted by
    (label, filename) — NA(0) first, then fist(1)…palm(5).  We rebuild that
    same sorted order from the image directory to pair each row correctly.

    Augmentation (training only):
      - Horizontal flip: applied SYNCHRONOUSLY to image + landmark x-coords
      - ColorJitter / rotation / blur: image only
      - Small Gaussian noise: landmarks only
    """

    def __init__(self, img_root: str, npz_path: str, augment: bool = False,
                 max_na_samples: int | None = None):
        data = np.load(npz_path)
        X = data['X']   # (N, 42)
        y = data['y']   # (N,)

        # Build image path list sorted by (label, filename) to match npz order.
        # npz order: NA(0) first, then fist(1)…palm(5).
        entries = []
        for cls_name in [NA_CLASS] + GESTURE_CLASSES:
            cls_idx = NA_IDX if cls_name == NA_CLASS else CLASS_TO_IDX[cls_name]
            img_dir = os.path.join(img_root, cls_name, 'crop_image')
            if not os.path.isdir(img_dir):
                continue
            for fname in sorted(os.listdir(img_dir)):
                if fname.lower().endswith('.png'):
                    entries.append((cls_idx, os.path.join(img_dir, fname)))

        entries.sort(key=lambda e: e[0])   # stable sort: label order matches npz
        paths      = [e[1] for e in entries]
        img_labels = np.array([e[0] for e in entries])

        if len(paths) != len(X) or not np.array_equal(img_labels, y):
            raise ValueError(
                f'Image-NPZ mismatch: {len(paths)} images vs {len(X)} npz rows, '
                f'or label order differs.'
            )

        if max_na_samples is not None:
            na_idx    = np.where(y == 0)[0]
            other_idx = np.where(y != 0)[0]
            if len(na_idx) > max_na_samples:
                rng = np.random.default_rng(seed=42)
                na_idx = rng.choice(na_idx, max_na_samples, replace=False)
            keep  = np.concatenate([na_idx, other_idx])
            np.random.default_rng(seed=0).shuffle(keep)
            X     = X[keep]
            y     = y[keep]
            paths = [paths[i] for i in keep]

        self.X      = X
        self.y      = y
        self.paths  = paths
        self.augment = augment

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        img     = Image.open(self.paths[idx]).convert('RGB')
        lm_flat = self.X[idx].copy()

        if self.augment and np.random.rand() < 0.5:
            img     = img.transpose(Image.FLIP_LEFT_RIGHT)
            lm      = lm_flat.reshape(21, 2)
            lm[:, 0] = 1.0 - lm[:, 0]
            lm_flat = lm.flatten()

        img_t   = _DUAL_IMG_JITTER(img) if self.augment else _DUAL_IMG_VAL(img)
        lm_feat = preprocess_landmarks(lm_flat, augment=False)
        if self.augment:
            lm_feat += np.random.normal(0, 0.01, lm_feat.shape).astype(np.float32)

        return img_t, torch.tensor(lm_feat, dtype=torch.float32), int(self.y[idx])
