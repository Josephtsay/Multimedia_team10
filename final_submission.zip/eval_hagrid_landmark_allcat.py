"""eval_hagrid_landmark_allcat.py

Evaluate the all-category landmark model
(checkpoints/hagrid_landmark_allcat_best.pth, trained by
train_hagrid_landmark_allcat.py) on the held-out TEST split.

That model outputs one of ~34 per-category logits (every HaGRIDv2 category gets
its own class, instead of collapsing ~29 of them into one N/A bucket). To stay
comparable with the assignment's +1/-2 scoring -- which only cares about
"target gesture" vs "N/A" -- predictions are collapsed AFTER inference:

    predicted category in TARGET_CATEGORIES -> that target's class id (1-5)
    predicted category is anything else      -> N/A (0)
    (then the usual confidence-threshold override is applied)

This script reports BOTH:
  1. Fine-grained per-category accuracy (exact-category match) -- the metric
     this training scheme actually optimizes for, e.g. "did a 'stop' sample
     get predicted as 'stop' specifically, or merely as some other non-target
     category?".
  2. The collapsed +1/-2 scoring summary, directly comparable to
     eval_hagrid_landmark.py's section 3.

Standalone experiment file -- eval_hagrid_landmark.py is left untouched.
"""

from __future__ import annotations

import os

import numpy as np
import torch
from torch.utils.data import DataLoader

from dataset import LANDMARK_FEATURE_DIM, NA_IDX, CLASS_TO_IDX
from models import LandmarkOnlyModel
from hagrid_landmark_data import TARGET_CATEGORIES
from hagrid_landmark_allcat_data import build_splits_by_ratio
from hagrid_landmark_cache import CachedHagridLandmarkDataset

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT = os.path.join(BASE, 'hagridv2_512_hand_preprocess_landmark')
CKPT = os.path.join(BASE, 'checkpoints', 'hagrid_landmark_allcat_best.pth')
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
BATCH_SIZE = 512
THRESHOLD = 0.5

TOP_K_ERRORS = 3


def load_model(num_classes: int):
    model = LandmarkOnlyModel(input_dim=LANDMARK_FEATURE_DIM, num_classes=num_classes).to(DEVICE)
    ckpt = torch.load(CKPT, map_location=DEVICE, weights_only=True)
    model.load_state_dict(ckpt['model_state'])
    model.eval()
    print(f'Loaded checkpoint: epoch={ckpt["epoch"]}  val_acc={ckpt["val_acc"]:.4f}  run_id={ckpt.get("run_id")}')
    print(f'Checkpoint size  : {os.path.getsize(CKPT) / 1024 ** 2:.2f} MB')
    return model


@torch.no_grad()
def run_inference(model, loader):
    """Returns (true_cat_idx, pred_cat_idx, max_prob) as numpy arrays.

    Both indices live in the FULL `all_categories` space (~34-way) -- nothing
    is collapsed here, so main() can build both the fine-grained report and the
    collapsed +1/-2 report from the same raw predictions.
    """
    all_true, all_pred, all_prob = [], [], []
    for feat, _label, cat_idx in loader:
        probs = torch.softmax(model(feat.to(DEVICE)), dim=-1)
        max_p, pred = probs.max(dim=-1)
        all_true.append(cat_idx)
        all_pred.append(pred.cpu())
        all_prob.append(max_p.cpu())
    return (torch.cat(all_true).numpy(), torch.cat(all_pred).numpy(), torch.cat(all_prob).numpy())


def fmt_breakdown(values: np.ndarray, names: list[str], k: int) -> str:
    """'name:count' for the top-k most frequent predicted categories in `values`."""
    if len(values) == 0:
        return '-'
    uniq, counts = np.unique(values, return_counts=True)
    order = np.argsort(-counts)[:k]
    return ', '.join(f'{names[uniq[i]]}:{counts[i]}' for i in order)


def main():
    _train_samples, _val_samples, test_samples, all_categories = build_splits_by_ratio(DATA_ROOT)
    # Cached dataset -- see precompute_hagrid_landmark_cache.py / hagrid_landmark_cache.py;
    # avoids re-reading ~100K small .npy files from disk for this report.
    test_ds = CachedHagridLandmarkDataset(test_samples, all_categories, augment=False)
    test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    print(f'Test samples: {len(test_ds)}  |  categories: {len(all_categories)}  |  threshold: {THRESHOLD}')

    model = load_model(num_classes=len(all_categories))
    true_idx, pred_idx, max_prob = run_inference(model, test_loader)
    true_names = np.array(all_categories)[true_idx]
    pred_names = np.array(all_categories)[pred_idx]

    # ════════════════════════════════════════════════════════════════════════
    # 1. Fine-grained per-category accuracy (exact-category match)
    # ════════════════════════════════════════════════════════════════════════
    print('\n' + '=' * 78)
    print(f'1. Fine-grained per-category accuracy (exact match across all {len(all_categories)} classes)')
    print('=' * 78)
    print(f'{"category":<18} {"n":>6} {"correct":>8} {"accuracy":>9}   '
          f'mispredicted as (top {TOP_K_ERRORS})')
    for cat in all_categories:
        mask = (true_names == cat)
        n = int(mask.sum())
        correct = int((pred_names[mask] == cat).sum())
        acc = correct / max(n, 1)
        wrong_mask = mask & (pred_names != cat)
        breakdown = fmt_breakdown(pred_idx[wrong_mask], all_categories, TOP_K_ERRORS)
        tag = '  (target)' if cat in TARGET_CATEGORIES else ''
        print(f'{cat:<18} {n:>6} {correct:>8} {acc:>9.4f}   {breakdown}{tag}')

    # ════════════════════════════════════════════════════════════════════════
    # 2. Collapsed +1/-2 scoring (predicted category -> target label or N/A)
    # ════════════════════════════════════════════════════════════════════════
    # This is what a predict()-style 6-class wrapper around this checkpoint
    # would have to do to satisfy the assignment's interface: keep the
    # prediction if it names one of the 5 targets, else report N/A. The
    # confidence threshold is applied on top, exactly like predict() does.
    target_idx_by_cat = {i: CLASS_TO_IDX[c] for i, c in enumerate(all_categories) if c in TARGET_CATEGORIES}
    collapsed_pred = np.array([target_idx_by_cat.get(p, NA_IDX) for p in pred_idx])
    collapsed_pred = np.where(max_prob >= THRESHOLD, collapsed_pred, NA_IDX)
    collapsed_true = np.array([CLASS_TO_IDX.get(c, NA_IDX) for c in true_names])

    is_target_true = collapsed_true != NA_IDX
    is_na_true = ~is_target_true

    correct_target = int(((collapsed_pred == collapsed_true) & is_target_true).sum())
    wrong_target = int(((collapsed_pred != collapsed_true) & is_target_true).sum())
    false_trigger_na = int(((collapsed_pred != NA_IDX) & is_na_true).sum())
    n_target = int(is_target_true.sum())
    n_na = int(is_na_true.sum())

    print('\n' + '=' * 78)
    print('2. Collapsed +1/-2 scoring (predicted category -> target label or N/A)')
    print('=' * 78)
    print(f'Target samples : {n_target:>6}   correct={correct_target:>5}   wrong={wrong_target:>5}   '
          f'acc={correct_target / max(n_target, 1):.4f}')
    print(f'N/A samples    : {n_na:>6}   false_trigger={false_trigger_na:>5}   '
          f'rate={false_trigger_na / max(n_na, 1):.4f}')
    score = correct_target - wrong_target * 2 - false_trigger_na * 2
    print(f'Score-style    : (+1 x {correct_target}) - (2 x {wrong_target}) - (2 x {false_trigger_na}) = {score}')


if __name__ == '__main__':
    main()
