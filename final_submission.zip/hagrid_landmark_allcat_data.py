"""hagrid_landmark_allcat_data.py

Ratio-based train/val/test split for the all-category landmark experiment
(train_hagrid_landmark_allcat.py / eval_hagrid_landmark_allcat.py).

hagrid_landmark_data.build_splits() uses FIXED per-category sample budgets
(e.g. TARGET_TRAIN_PER_CLASS=16000, OTHER_TRAIN_PER_CLASS=800). That is fine for
the 6-class (5 targets + collapsed N/A) setup, where every "other" category is
just N/A filler and its individual size doesn't matter.

The all-category setup is different: every category becomes its own class, so
how much of EACH category's data lands in train vs. val vs. test directly
shapes what the model learns to recognize as that category -- and categories
vary widely in how many raw samples they have. A fixed budget would either
truncate larger categories inconsistently or be infeasible for smaller ones.
Splitting every category by the same RATIO (8:1:1) keeps the train/val/test
proportions identical for every category regardless of its absolute size.

Reuses `list_categories` / `_list_npy` / `SEED` from hagrid_landmark_data.py and
`CLASS_TO_IDX` / `NA_IDX` from dataset.py unchanged -- only the split strategy
differs. `HagridLandmarkDataset` (also unchanged) consumes the resulting
samples exactly as it does hagrid_landmark_data.build_splits()'s output.
"""

from __future__ import annotations

import os
import random

from dataset import CLASS_TO_IDX, NA_IDX
from hagrid_landmark_data import SEED, TARGET_CATEGORIES, list_categories, _list_npy

TRAIN_RATIO = 0.8
VAL_RATIO = 0.1
TEST_RATIO = 0.1

# Cap on how many files an "other" (non-target / N/A) category contributes to
# the split, applied BEFORE the 8:1:1 cut. The 5 target categories are exempt
# (always use everything available). Categories with fewer than this many
# files just use however many they have -- the cap only ever shrinks the pool,
# never pads it.
OTHER_CATEGORY_CAP = 5000


def build_splits_by_ratio(root: str, train_ratio: float = TRAIN_RATIO,
                          val_ratio: float = VAL_RATIO, test_ratio: float = TEST_RATIO,
                          other_category_cap: int = OTHER_CATEGORY_CAP,
                          exclude_categories: tuple[str, ...] = ()):
    """Returns (train_samples, val_samples, test_samples, all_categories).

    Every category's files are shuffled (deterministically, via the shared
    SEED). For "other" (non-target) categories, the shuffled file list is first
    truncated to at most `other_category_cap` files (categories with fewer
    files are left as-is); the 5 target categories are never truncated. The
    resulting pool is then cut at `train_ratio : val_ratio : test_ratio` --
    e.g. a category with 1000 files (after capping) yields roughly 800/100/100,
    one with 100 files yields 80/10/10. The three lists stay disjoint, exactly
    like hagrid_landmark_data.build_splits().

    `exclude_categories`: category names dropped entirely from `all_categories`
    (and therefore from train/val/test) -- e.g. ('no_gesture',). Default ()
    keeps existing behaviour (and existing checkpoints, which embed their own
    `all_categories`) unchanged.

    Each sample is (npy_path, label[0-5], category_name) -- the same tuple
    shape `HagridLandmarkDataset` already expects, so it can be reused as-is.
    `label` mirrors hagrid_landmark_data's convention (CLASS_TO_IDX for the 5
    targets, NA_IDX for everything else) purely for drop-in compatibility with
    the 6-class scripts; train_hagrid_landmark_allcat.py ignores it and trains
    on `category_idx` instead.
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-9
    rng = random.Random(SEED)
    all_categories = [c for c in list_categories(root) if c not in exclude_categories]

    train_samples: list[tuple[str, int, str]] = []
    val_samples: list[tuple[str, int, str]] = []
    test_samples: list[tuple[str, int, str]] = []

    for cat in all_categories:
        cat_dir = os.path.join(root, cat)
        files = _list_npy(cat_dir)
        rng.shuffle(files)
        if cat not in TARGET_CATEGORIES:
            files = files[:other_category_cap]
        n = len(files)
        n_train = min(int(round(n * train_ratio)), n)
        n_val = min(int(round(n * val_ratio)), n - n_train)
        # remainder -> test, so the three counts always sum to exactly `n`

        label = CLASS_TO_IDX.get(cat, NA_IDX)
        a, b = n_train, n_train + n_val
        for f in files[:a]:
            train_samples.append((os.path.join(cat_dir, f), label, cat))
        for f in files[a:b]:
            val_samples.append((os.path.join(cat_dir, f), label, cat))
        for f in files[b:]:
            test_samples.append((os.path.join(cat_dir, f), label, cat))

    rng.shuffle(train_samples)
    rng.shuffle(val_samples)
    rng.shuffle(test_samples)
    return train_samples, val_samples, test_samples, all_categories
