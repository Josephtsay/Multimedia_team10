"""hagrid_landmark_cache.py

In-RAM cached counterpart to HagridLandmarkDataset (hagrid_landmark_data.py),
for the full-category landmark experiments
(train_hagrid_landmark_allcat.py / eval_hagrid_landmark_allcat.py).

HagridLandmarkDataset.__getitem__ calls np.load(path) on every access -- with
~1M samples per epoch under the new 8:1:1 ratio split
(hagrid_landmark_allcat_data.py), that's ~1M small-file disk reads per epoch,
which starves the GPU (it finishes each tiny-MLP batch instantly, then waits on
disk I/O; nvidia-smi shows ~0% utilization while training runs).

CachedHagridLandmarkDataset instead loads the single cache file produced by
precompute_hagrid_landmark_cache.py (every sample's raw (42,) landmarks, keyed
by its full path) into RAM ONCE at construction time, resolves each sample's
row index up front, and serves __getitem__ by plain array indexing -- zero
per-sample disk reads.

preprocess_landmarks() (including augmentation) still runs per __getitem__ call
on the cached (42,) array -- it's pure, cheap numpy on a tiny array, so
training-time augmentation behaves identically to HagridLandmarkDataset. Only
the disk-I/O part is removed.

Drop-in replacement: identical constructor signature and __getitem__ return
shape -- (feature[66], label[0-5], category_idx).
"""

from __future__ import annotations

import os

import numpy as np
import torch
from torch.utils.data import Dataset

from dataset import preprocess_landmarks

BASE = os.path.dirname(os.path.abspath(__file__))
CACHE_PATH = os.path.join(BASE, 'landmarks_npz', 'hagrid_allcat_landmark_cache.npz')

_cache = None  # (X, path_to_row) -- loaded once, shared by every dataset instance


def _load_cache():
    global _cache
    if _cache is None:
        if not os.path.exists(CACHE_PATH):
            raise FileNotFoundError(
                f'Landmark cache not found at {CACHE_PATH}.\n'
                f'Run `python precompute_hagrid_landmark_cache.py` once first.')
        data = np.load(CACHE_PATH, allow_pickle=True)
        X = data['X']
        # normcase so lookups are robust to drive-letter / slash case differences
        # (e.g. running from PowerShell vs. a bash shell on Windows can yield
        # 'D:\\...' vs 'd:\\...' for the same file).
        path_to_row = {os.path.normcase(p): i for i, p in enumerate(data['paths'])}
        _cache = (X, path_to_row)
        print(f'[hagrid_landmark_cache] loaded {X.shape[0]} cached landmarks '
              f'({X.nbytes / 1024 ** 2:.1f} MB) from {CACHE_PATH}')
    return _cache


class CachedHagridLandmarkDataset(Dataset):
    """Yields (feature[66], label[0-5], category_idx) -- identical contract to
    HagridLandmarkDataset, but reads raw landmarks from an in-RAM cache built
    by precompute_hagrid_landmark_cache.py instead of the filesystem."""

    def __init__(self, samples: list[tuple[str, int, str]], all_categories: list[str], augment: bool = False):
        X, path_to_row = _load_cache()
        self._X = X
        self.cat_to_idx = {c: i for i, c in enumerate(all_categories)}
        self.augment = augment

        try:
            self._rows = np.array([path_to_row[os.path.normcase(path)] for path, _label, _cat in samples], dtype=np.int64)
        except KeyError as e:
            raise RuntimeError(
                f'Sample path missing from landmark cache: {e.args[0]}\n'
                f'The dataset directory likely changed since the cache was built '
                f'(e.g. filter_polluted_hagrid.py quarantined files) -- '
                f're-run `python precompute_hagrid_landmark_cache.py`.'
            ) from e
        self._labels = np.array([label for _path, label, _cat in samples], dtype=np.int64)
        self._cat_idx = np.array([self.cat_to_idx[cat] for _path, _label, cat in samples], dtype=np.int64)

    def __len__(self) -> int:
        return len(self._rows)

    def __getitem__(self, idx: int):
        lm_flat = self._X[self._rows[idx]]
        feat = preprocess_landmarks(lm_flat, augment=self.augment)
        return torch.from_numpy(feat), int(self._labels[idx]), int(self._cat_idx[idx])
