"""hagrid_landmark_data.py

Shared data utilities for the HaGRIDv2-full-category landmark experiment
(train_hagrid_landmark.py / eval_hagrid_landmark.py).

Builds a deterministic, mutually-exclusive 3-way train / val / test split
directly from hagridv2_512_hand_preprocess_landmark/<category>/<uuid>.npy:

  - the 5 baseline target categories -> training labels 1-5
    (fist, like, ok, one, palm -- via dataset.CLASS_TO_IDX)
  - every OTHER HaGRIDv2 category    -> training label 0 (N/A), with the
    ORIGINAL category name retained per-sample so eval_hagrid_landmark.py can
    report false-trigger rates broken down by source category, e.g. "how often
    does a 'call' sample get misread as one of the 5 target gestures?".

The three splits serve distinct purposes and never overlap:
  - train : seen by the optimizer (train_hagrid_landmark.py, augment=True)
  - val   : used during training to pick the best checkpoint
            (train_hagrid_landmark.py, augment=False)
  - test  : NEVER seen during training -- held out purely for the final,
            per-category report (eval_hagrid_landmark.py). Keeping this
            disjoint from `val` avoids the "validation leakage" that a 2-way
            split would have (checkpoint selection and final reporting both
            reading the same held-out set would bias the final numbers
            slightly optimistic).

Both scripts import `build_splits` (same SEED, same sorted file listing) so
they always see byte-identical partitions without needing to persist an index
file. Samples quarantined by filter_polluted_hagrid.py (moved into
<root>/_polluted/<category>/) live in a sibling directory and are therefore
excluded automatically by `list_categories` (it skips dirs starting with '_').

`preprocess_landmarks` / `LANDMARK_FEATURE_DIM` are reused unchanged from
dataset.py -- the landmark feature format is fixed by project spec and must not
be modified.
"""

from __future__ import annotations

import os
import random

import numpy as np
import torch
from torch.utils.data import Dataset

from dataset import preprocess_landmarks, CLASS_TO_IDX, NA_IDX, GESTURE_CLASSES

SEED = 42
TARGET_CATEGORIES = GESTURE_CLASSES  # ['fist', 'like', 'ok', 'one', 'palm'] -> labels 1-5

# Per-category sample budgets (train + val + test must fit within the smallest
# category's count -- 'no_gesture' has ~2.1K, and 6000 / 600 both fit easily):
#   train = 5*4000 + 29*400 = 31,600
#   val   = 5* 500 + 29*100 =  5,400
#   test  = 5*1000 + 29*100 =  7,900
TARGET_TRAIN_PER_CLASS = 16000
TARGET_VAL_PER_CLASS = 2000
TARGET_TEST_PER_CLASS = 2000
OTHER_TRAIN_PER_CLASS = 800
OTHER_VAL_PER_CLASS = 200
OTHER_TEST_PER_CLASS = 200


def _list_npy(cat_dir: str) -> list[str]:
    return sorted(f for f in os.listdir(cat_dir) if f.endswith('.npy'))


def list_categories(root: str) -> list[str]:
    """All category folders under root, excluding quarantine dirs (leading '_')."""
    return sorted(
        d for d in os.listdir(root)
        if os.path.isdir(os.path.join(root, d)) and not d.startswith('_')
    )


def build_splits(root: str):
    """Returns (train_samples, val_samples, test_samples, all_categories).

    Each sample is a tuple (npy_path, label[0-5], category_name). The three
    lists are disjoint (each file is drawn into at most one of them).
    `all_categories` is the full sorted category list (targets + others); it
    gives every dataset a stable category<->index mapping for batching.
    """
    rng = random.Random(SEED)
    all_categories = list_categories(root)
    other_categories = [c for c in all_categories if c not in TARGET_CATEGORIES]

    train_samples: list[tuple[str, int, str]] = []
    val_samples: list[tuple[str, int, str]] = []
    test_samples: list[tuple[str, int, str]] = []

    def _split(cat: str, label: int, n_train: int, n_val: int, n_test: int) -> None:
        cat_dir = os.path.join(root, cat)
        files = _list_npy(cat_dir)
        rng.shuffle(files)
        files = files[:n_train + n_val + n_test]
        a, b = n_train, n_train + n_val
        for f in files[:a]:
            train_samples.append((os.path.join(cat_dir, f), label, cat))
        for f in files[a:b]:
            val_samples.append((os.path.join(cat_dir, f), label, cat))
        for f in files[b:b + n_test]:
            test_samples.append((os.path.join(cat_dir, f), label, cat))

    for cat in TARGET_CATEGORIES:
        _split(cat, CLASS_TO_IDX[cat], TARGET_TRAIN_PER_CLASS, TARGET_VAL_PER_CLASS, TARGET_TEST_PER_CLASS)
    for cat in other_categories:
        _split(cat, NA_IDX, OTHER_TRAIN_PER_CLASS, OTHER_VAL_PER_CLASS, OTHER_TEST_PER_CLASS)

    rng.shuffle(train_samples)
    rng.shuffle(val_samples)
    rng.shuffle(test_samples)
    return train_samples, val_samples, test_samples, all_categories


class HagridLandmarkDataset(Dataset):
    """Yields (feature[66], label[0-5], category_idx) for each sample.

    `category_idx` indexes into the shared `all_categories` list -- it lets
    eval_hagrid_landmark.py recover each sample's ORIGINAL HaGRIDv2 category
    after DataLoader batching/collation (plain strings can't be collated).
    """

    def __init__(self, samples: list[tuple[str, int, str]], all_categories: list[str], augment: bool = False):
        self.samples = samples
        self.cat_to_idx = {c: i for i, c in enumerate(all_categories)}
        self.augment = augment

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int):
        path, label, category = self.samples[idx]
        arr = np.load(path).astype(np.float32)
        if arr.ndim == 2 and arr.shape[1] >= 2:
            arr = arr[:, :2]
        lm_flat = arr.reshape(-1)  # (42,)
        feat = preprocess_landmarks(lm_flat, augment=self.augment)
        return torch.from_numpy(feat), label, self.cat_to_idx[category]
