import torch
import torch.nn as nn
import torchvision.models as models


class ImageBranch(nn.Module):
    """EfficientNet-B0 backbone that outputs a 256-dim feature vector."""

    def __init__(self):
        super().__init__()
        backbone = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.IMAGENET1K_V1)
        # Replace classifier: Dropout + Linear(1280 → 256)
        backbone.classifier = nn.Sequential(
            nn.Dropout(0.2),
            nn.Linear(1280, 256),
        )
        self.backbone = backbone

    def forward(self, x):
        return self.backbone(x)  # (B, 256)


class ImageOnlyModel(nn.Module):
    """Step 1 — image branch only, classifies 5 gesture classes (no N/A).

    Training labels: 0=fist, 1=like, 2=ok, 3=one, 4=palm
    Final output mapping: training_idx + 1  → 1=fist … 5=palm
    """

    def __init__(self, num_classes=5):
        super().__init__()
        self.image_branch = ImageBranch()
        self.classifier = nn.Sequential(
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes),
        )

    def forward(self, x):
        feat = self.image_branch(x)
        return self.classifier(feat)


class LandmarkOnlyModel(nn.Module):
    """Step 2 (main plan) — landmark-only MLP.

    input_dim: LANDMARK_FEATURE_DIM from dataset.py (57 by default)
    Estimated size: ~240 KB — well under the 10 MB limit.
    """

    def __init__(self, input_dim: int = 57, num_classes: int = 6):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class DualBranchModel(nn.Module):
    """Step 2+ — fuses image features with landmark MLP features.

    num_classes=6 includes N/A (class 0).
    """

    def __init__(self, num_classes=6):
        super().__init__()
        self.image_branch = ImageBranch()

        self.landmark_mlp = nn.Sequential(
            nn.Linear(42, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
        )

        self.classifier = nn.Sequential(
            nn.Linear(256 + 64, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes),
        )

    def forward(self, img, landmarks):
        img_feat = self.image_branch(img)          # (B, 256)
        lm_feat = self.landmark_mlp(landmarks)     # (B, 64)
        fused = torch.cat([img_feat, lm_feat], dim=1)  # (B, 320)
        return self.classifier(fused)


class LightDualBranchModel(nn.Module):
    """Step 3 — MobileNetV3-Small image branch + landmark MLP, fused.

    Image branch : MobileNetV3-Small (ImageNet pretrained) → 64-dim
    Landmark branch: 66→256→128→64-dim  (same capacity as LandmarkOnlyModel)
    Fusion head   : 128 → 64 → 6

    Estimated .pth size: ~4–5 MB (well under 10 MB limit).
    Size score = (10 − size) × 3 ≈ 15–18 pts.
    """

    def __init__(self, lm_input_dim: int = 66, num_classes: int = 6):
        super().__init__()

        # ── image branch ──────────────────────────────────────────────────────
        backbone = models.mobilenet_v3_small(
            weights=models.MobileNet_V3_Small_Weights.IMAGENET1K_V1
        )
        # MobileNetV3-Small: features output 576-ch after avgpool + flatten.
        # Replace the heavy 576→1024→1000 head with a lightweight 576→64 head.
        backbone.classifier = nn.Sequential(
            nn.Linear(576, 128),
            nn.Hardswish(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
        )
        self.img_branch = backbone

        # ── landmark branch ───────────────────────────────────────────────────
        self.lm_branch = nn.Sequential(
            nn.Linear(lm_input_dim, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
        )

        # ── fusion head ───────────────────────────────────────────────────────
        self.head = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, num_classes),
        )

    def forward(self, img: torch.Tensor, lm: torch.Tensor) -> torch.Tensor:
        img_feat = self.img_branch(img)        # (B, 64)
        lm_feat  = self.lm_branch(lm)         # (B, 64)
        fused    = torch.cat([img_feat, lm_feat], dim=1)  # (B, 128)
        return self.head(fused)


class ShuffleDualBranchModel(nn.Module):
    """Step 3v2 — ShuffleNetV2-x0.5 image branch + landmark MLP, fused.

    Image branch : ShuffleNetV2-x0.5 (ImageNet pretrained), fc replaced → 64-dim
    Landmark branch: 66→256→128→64-dim
    Fusion head   : 128 → 64 → 6

    ShuffleNetV2-x0.5 has ~350K backbone params; estimated .pth ~1.5 MB.
    Size score = (10 − size) × 3 ≈ 25 pts.
    """

    def __init__(self, lm_input_dim: int = 66, num_classes: int = 6):
        super().__init__()

        # ── image branch ──────────────────────────────────────────────────────
        backbone = models.shufflenet_v2_x0_5(
            weights=models.ShuffleNet_V2_X0_5_Weights.IMAGENET1K_V1
        )
        # ShuffleNetV2-x0.5: global-avg-pool output is 1024-dim → fed into fc.
        backbone.fc = nn.Sequential(
            nn.Linear(1024, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
        )
        self.img_branch = backbone

        # ── landmark branch ───────────────────────────────────────────────────
        self.lm_branch = nn.Sequential(
            nn.Linear(lm_input_dim, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
        )

        # ── fusion head ───────────────────────────────────────────────────────
        self.head = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, num_classes),
        )

    def forward(self, img: torch.Tensor, lm: torch.Tensor) -> torch.Tensor:
        img_feat = self.img_branch(img)        # (B, 64)
        lm_feat  = self.lm_branch(lm)         # (B, 64)
        return self.head(torch.cat([img_feat, lm_feat], dim=1))
