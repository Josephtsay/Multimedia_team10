"""precompute_hagrid_landmark_cache.py

One-time cache-builder for the full-category HaGRIDv2 landmark experiments
(train_hagrid_landmark_allcat.py / eval_hagrid_landmark_allcat.py and the
8:1:1 ratio split in hagrid_landmark_allcat_data.py).

Why: HagridLandmarkDataset.__getitem__ re-reads each sample's raw landmark
.npy from disk on every single access. With the new ratio-based 8:1:1 split
that's roughly 1M small-file reads PER EPOCH -- the GPU finishes each
tiny-MLP batch almost instantly and then sits idle waiting on disk I/O
(nvidia-smi shows ~0% utilization while training runs). The bottleneck is the
repeated filesystem access, not the (cheap, pure-numpy) feature transform.

This script calls build_splits_by_ratio() (the same 8:1:1 + OTHER_CATEGORY_CAP
split used by training/eval) to get the exact set of files actually needed
(~275K, not the ~1M raw files across all categories), loads each raw (21, 2)
landmark array, and stacks them into a single cache file (full path + raw
(42,) landmarks). CachedHagridLandmarkDataset (hagrid_landmark_cache.py) then
loads this cache into RAM at construction time and serves every sample by
plain array indexing -- zero per-sample disk reads during training.

Note: only the RAW landmarks are cached, NOT the final 66-dim features --
preprocess_landmarks() (including augmentation) still runs per __getitem__
call on the cached (42,) array, so training-time augmentation behaves exactly
as before. Only the disk-I/O part is removed.

Run once (re-run if the dataset directory contents change, e.g. after
filter_polluted_hagrid.py quarantines new files):

    python precompute_hagrid_landmark_cache.py
"""

from __future__ import annotations

import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from hagrid_landmark_allcat_data import build_splits_by_ratio

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT = os.path.join(BASE, 'hagridv2_512_hand_preprocess_landmark')
CACHE_DIR = os.path.join(BASE, 'landmarks_npz')
CACHE_PATH = os.path.join(CACHE_DIR, 'hagrid_allcat_landmark_cache.npz')

# np.load() on a small file is dominated by the open()/read() syscalls, which
# release the GIL -- a thread pool overlaps that I/O wait across many files at
# once instead of doing it one file at a time (a quick single-threaded test
# showed ~95% wall-clock time spent blocked on disk for ~1M tiny files).
IO_WORKERS = 32


def _load_one(path: str):
    """Returns (path, (42,) float32 landmarks) or (path, None) if unreadable."""
    try:
        arr = np.load(path).astype(np.float32)
    except Exception:
        return path, None
    if arr.ndim != 2 or arr.shape[0] < 21 or arr.shape[1] < 2:
        return path, None
    return path, arr[:21, :2].reshape(-1)  # (42,) crop-relative xy


def main():
    os.makedirs(CACHE_DIR, exist_ok=True)

    train_s, val_s, test_s, all_categories = build_splits_by_ratio(DATA_ROOT)
    needed_paths = sorted({p for p, _label, _cat in train_s + val_s + test_s})
    print(f'Root       : {DATA_ROOT}')
    print(f'Categories : {len(all_categories)}')
    print(f'Files needed (train+val+test, deduped): {len(needed_paths)}')
    print(f'IO workers : {IO_WORKERS}')
    print('-' * 72)
    sys.stdout.flush()

    all_paths: list[str] = []
    all_X: list[np.ndarray] = []
    skipped = 0

    t0 = time.time()
    CHUNK = 5000
    with ThreadPoolExecutor(max_workers=IO_WORKERS) as pool:
        for i in range(0, len(needed_paths), CHUNK):
            chunk = needed_paths[i:i + CHUNK]
            for path, lm in pool.map(_load_one, chunk):
                if lm is None:
                    skipped += 1
                    continue
                all_paths.append(path)
                all_X.append(lm)
            done = min(i + CHUNK, len(needed_paths))
            print(f'  {done:>7} / {len(needed_paths)}  ({time.time() - t0:.1f}s elapsed)')
            sys.stdout.flush()

    X = np.stack(all_X).astype(np.float32)         # (N, 42)
    paths = np.array(all_paths, dtype=object)      # (N,) full path strings

    print('-' * 72)
    print(f'Total cached : {len(paths)}  (skipped {skipped})  |  {time.time() - t0:.1f}s')
    print(f'X shape      : {X.shape}  ({X.nbytes / 1024 ** 2:.1f} MB raw)')
    sys.stdout.flush()

    np.savez_compressed(CACHE_PATH, X=X, paths=paths)
    print(f'Saved cache  : {CACHE_PATH}  ({os.path.getsize(CACHE_PATH) / 1024 ** 2:.1f} MB on disk)')
    print('\nNext: train_hagrid_landmark_allcat.py / eval_hagrid_landmark_allcat.py '
          'now load this cache automatically via hagrid_landmark_cache.py.')


if __name__ == '__main__':
    main()
