"""train_hagrid_landmark_allcat.py

Train a landmark-only MLP that predicts each HaGRIDv2 category SEPARATELY
(~34-way classification) instead of collapsing every non-target category into
a single N/A bucket the way train_hagrid_landmark.py does.

Why: train_hagrid_landmark.py's N/A class lumps ~29 visually-distinct gestures
(stop, mute, grabbing, ...) into one output, so the model only ever has to draw
ONE boundary between "target" and "everything else" -- it never gets a signal
that distinguishes, say, "stop" from "mute". This script instead gives every
category its own output index, using HagridLandmarkDataset's `category_idx`
(already a stable per-category label derived from the shared `all_categories`
ordering -- no change to hagrid_landmark_data.py needed) as the training
target, so the model has to learn fine-grained boundaries everywhere. At
eval time, predictions for non-target categories are collapsed back to N/A for
+1/-2 scoring (see eval_hagrid_landmark_allcat.py).

Standalone experiment file -- train_hagrid_landmark.py / eval_hagrid_landmark.py
are left untouched.
"""

from __future__ import annotations

import os
import time
from collections import Counter
from datetime import datetime

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from dataset import LANDMARK_FEATURE_DIM
from models import LandmarkOnlyModel
from hagrid_landmark_allcat_data import build_splits_by_ratio
from hagrid_landmark_cache import CachedHagridLandmarkDataset

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT = os.path.join(BASE, 'hagridv2_512_hand_preprocess_landmark')
CKPT_DIR = os.path.join(BASE, 'checkpoints')
os.makedirs(CKPT_DIR, exist_ok=True)
BEST_CKPT = os.path.join(CKPT_DIR, 'hagrid_landmark_allcat_best.pth')

BATCH_SIZE = 512
EPOCHS = 80
WARMUP_EPOCHS = 3
LR = 1e-3
WEIGHT_DECAY = 1e-4
FOCAL_GAMMA = 2.0
NUM_WORKERS = 4
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class FocalLoss(nn.Module):
    """Standard multi-class focal loss with optional per-class weighting."""

    def __init__(self, gamma: float = 2.0, weight: torch.Tensor | None = None):
        super().__init__()
        self.gamma = gamma
        if weight is not None:
            self.register_buffer('weight', weight)
        else:
            self.weight = None

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        log_p = F.log_softmax(logits, dim=-1)
        log_pt = log_p[torch.arange(len(targets), device=logits.device), targets]
        pt = log_pt.exp()
        loss = -(1 - pt) ** self.gamma * log_pt
        if self.weight is not None:
            loss = loss * self.weight[targets]
        return loss.mean()


def class_weights_from_samples(train_samples, all_categories) -> torch.Tensor:
    """Inverse-frequency weights over `all_categories`, mean-normalised to ~1.

    Needed because the per-category sample budget in hagrid_landmark_data.py is
    heavily skewed -- the 5 target categories get TARGET_TRAIN_PER_CLASS samples
    each while every other category only gets OTHER_TRAIN_PER_CLASS (a ~20x
    gap). Without this, the ~29 "other" classes would be starved relative to
    the 5 target classes in this fine-grained setup.
    """
    cat_to_idx = {c: i for i, c in enumerate(all_categories)}
    counts = Counter(cat_to_idx[cat] for _, _label, cat in train_samples)
    inv = torch.tensor([1.0 / counts[i] for i in range(len(all_categories))], dtype=torch.float32)
    return inv / inv.mean()


def make_loaders():
    # `test_samples` stays unseen here (held out for eval_hagrid_landmark_allcat.py),
    # mirroring train_hagrid_landmark.py's split discipline. Unlike that script,
    # the split itself is ratio-based (8:1:1 per category, see
    # hagrid_landmark_allcat_data.py) rather than a fixed per-category budget --
    # categories vary too much in raw sample count for a fixed budget to make
    # sense once every category is its own class.
    train_samples, val_samples, _test_samples, all_categories = build_splits_by_ratio(DATA_ROOT)
    # Cached dataset: raw landmarks live in RAM (see precompute_hagrid_landmark_cache.py /
    # hagrid_landmark_cache.py) -- __getitem__ does zero disk reads, only the cheap
    # preprocess_landmarks() transform (with augmentation, same as before) runs live.
    # This removes the ~1M-reads-per-epoch disk-I/O bottleneck that was starving the GPU.
    train_ds = CachedHagridLandmarkDataset(train_samples, all_categories, augment=True)
    val_ds = CachedHagridLandmarkDataset(val_samples, all_categories, augment=False)
    print(f'Train: {len(train_ds)} | Val: {len(val_ds)} | categories: {len(all_categories)}')
    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,
                              num_workers=NUM_WORKERS, persistent_workers=NUM_WORKERS > 0,
                              drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False,
                            num_workers=NUM_WORKERS, persistent_workers=NUM_WORKERS > 0)
    return train_loader, val_loader, train_samples, all_categories


def train_one_epoch(model, loader, criterion, optimizer):
    model.train()
    total_loss = correct = total = 0
    for feat, _label, cat_idx in loader:
        feat, y = feat.to(DEVICE), cat_idx.to(DEVICE)
        optimizer.zero_grad()
        logits = model(feat)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * feat.size(0)
        correct += (logits.argmax(1) == y).sum().item()
        total += feat.size(0)
    return total_loss / total, correct / total


@torch.no_grad()
def evaluate(model, loader, criterion):
    model.eval()
    total_loss = correct = total = 0
    for feat, _label, cat_idx in loader:
        feat, y = feat.to(DEVICE), cat_idx.to(DEVICE)
        logits = model(feat)
        loss = criterion(logits, y)
        total_loss += loss.item() * feat.size(0)
        correct += (logits.argmax(1) == y).sum().item()
        total += feat.size(0)
    return total_loss / total, correct / total


def main():
    run_id = datetime.now().strftime('%Y%m%d_%H%M')
    print(f'Device: {DEVICE} | Run: {run_id} | landmark feature dim: {LANDMARK_FEATURE_DIM}')

    train_loader, val_loader, train_samples, all_categories = make_loaders()
    num_classes = len(all_categories)
    print(f'Fine-grained classes: {num_classes} (every category gets its own output)')
    model = LandmarkOnlyModel(input_dim=LANDMARK_FEATURE_DIM, num_classes=num_classes).to(DEVICE)

    weights = class_weights_from_samples(train_samples, all_categories)
    criterion = FocalLoss(gamma=FOCAL_GAMMA, weight=weights.to(DEVICE))
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)

    warmup = torch.optim.lr_scheduler.LinearLR(optimizer, start_factor=0.1, total_iters=WARMUP_EPOCHS)
    cosine = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS - WARMUP_EPOCHS)
    scheduler = torch.optim.lr_scheduler.SequentialLR(optimizer, [warmup, cosine], milestones=[WARMUP_EPOCHS])

    best_val_acc = 0.0
    for epoch in range(1, EPOCHS + 1):
        t0 = time.time()
        tr_loss, tr_acc = train_one_epoch(model, train_loader, criterion, optimizer)
        va_loss, va_acc = evaluate(model, val_loader, criterion)
        scheduler.step()
        marker = ''
        if va_acc > best_val_acc:
            best_val_acc = va_acc
            torch.save({'epoch': epoch, 'model_state': model.state_dict(),
                        'val_acc': va_acc, 'run_id': run_id,
                        'all_categories': all_categories}, BEST_CKPT)
            marker = '  -> saved'
        print(f'E{epoch:02d}/{EPOCHS} | train loss {tr_loss:.4f} acc {tr_acc:.4f} | '
              f'val loss {va_loss:.4f} acc {va_acc:.4f} | {time.time() - t0:.1f}s{marker}')

    print(f'\nBest val acc : {best_val_acc:.4f}  (fine-grained, {num_classes}-way)')
    print(f'Checkpoint   : {BEST_CKPT}')


if __name__ == '__main__':
    main()
