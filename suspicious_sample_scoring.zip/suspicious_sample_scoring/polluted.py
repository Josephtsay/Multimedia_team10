import argparse
from pathlib import Path

import numpy as np
import pandas as pd


CLASS_NAMES = ["na", "fist", "like", "ok", "one", "palm"]
TARGET_LABELS = [1, 2, 3, 4, 5]
TIPS = [4, 8, 12, 16, 20]
MCPS = [1, 5, 9, 13, 17]
PIPS = [2, 6, 10, 14, 18]
DIPS = [3, 7, 11, 15, 19]
HAND_EDGES = [
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (0, 9), (9, 10), (10, 11), (11, 12),
    (0, 13), (13, 14), (14, 15), (15, 16),
    (0, 17), (17, 18), (18, 19), (19, 20),
]
ANGLE_TRIPLETS = [
    (1, 2, 3), (2, 3, 4),
    (5, 6, 7), (6, 7, 8),
    (9, 10, 11), (10, 11, 12),
    (13, 14, 15), (14, 15, 16),
    (17, 18, 19), (18, 19, 20),
]
ADJ_TIP_PAIRS = [(4, 8), (8, 12), (12, 16), (16, 20)]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Detect likely wrong-hand polluted target landmarks and write a cleaned NPZ."
    )
    parser.add_argument("--in-npz", default="landmark.npz", help="Input NPZ with L/y arrays.")
    parser.add_argument("--out-npz", default="landmark.clean.npz", help="Cleaned output NPZ.")
    parser.add_argument("--report", default="polluted_report.csv", help="CSV report for removed samples.")
    parser.add_argument(
        "--drop-rate",
        type=float,
        default=0.12,
        help="Fraction removed per target class. Default removes the worst 12% target samples.",
    )
    parser.add_argument(
        "--min-flag-score",
        type=float,
        default=0.0,
        help="Optional minimum combined score. Default 0 keeps exactly drop-rate per target class.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only write report; do not write cleaned NPZ.",
    )
    return parser.parse_args()


def to_landmarks(lm):
    lm = np.asarray(lm, dtype=np.float32)
    if lm.ndim == 1:
        if lm.size == 42:
            lm = lm.reshape(21, 2)
        elif lm.size == 63:
            lm = lm.reshape(21, 3)
        else:
            raise ValueError(f"bad flat landmark size: {lm.size}")
    if lm.ndim != 2 or lm.shape[0] != 21 or lm.shape[1] not in (2, 3):
        raise ValueError(f"bad landmark shape: {lm.shape}")
    if not np.all(np.isfinite(lm)):
        raise ValueError("landmark contains NaN/Inf")
    return lm.astype(np.float32)


def safe_norm(x):
    return float(np.linalg.norm(x) + 1e-6)


def cos_angle(a, b, c):
    u = a - b
    v = c - b
    return float(np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v) + 1e-6))


def normalize_lm(lm):
    out = to_landmarks(lm).copy()
    xy = out[:, :2]
    xy -= xy[0:1]
    scale = np.linalg.norm(((xy[5] + xy[17]) * 0.5) - xy[0])
    if scale < 1e-6:
        scale = np.linalg.norm(xy[9] - xy[0]) + 1e-6
    xy /= scale + 1e-6
    out[:, :2] = xy
    if out.shape[1] == 3:
        out[:, 2] = (out[:, 2] - out[0, 2]) / (scale + 1e-6)
    return out.astype(np.float32)


def finger_extension_scores(nlm):
    xy = nlm[:, :2]
    center = (xy[0] + xy[5] + xy[17]) / 3.0
    scores = []
    for tip, mcp, pip, dip in zip(TIPS, MCPS, PIPS, DIPS):
        tip_dist = safe_norm(xy[tip] - center)
        mcp_dist = safe_norm(xy[mcp] - center)
        bone = safe_norm(xy[mcp] - xy[pip]) + safe_norm(xy[pip] - xy[dip]) + safe_norm(xy[dip] - xy[tip])
        ext = (tip_dist - mcp_dist) / (bone + 1e-6)
        if tip == 4:
            a1 = -cos_angle(xy[1], xy[2], xy[3])
            a2 = -cos_angle(xy[2], xy[3], xy[4])
        else:
            a1 = -cos_angle(xy[mcp], xy[pip], xy[dip])
            a2 = -cos_angle(xy[pip], xy[dip], xy[tip])
        scores.append(0.65 * ext + 0.35 * (a1 + a2) * 0.5)
    return np.asarray(scores, dtype=np.float32)


def validity_template_scores(nlm):
    xy = nlm[:, :2]
    ext = finger_extension_scores(nlm)
    e = 1.0 / (1.0 + np.exp(-3.0 * (ext - 0.25)))
    thumb, index, middle, ring, pinky = e
    pinch = safe_norm(xy[4] - xy[8])
    spread = np.mean([safe_norm(xy[i] - xy[j]) for i, j in ADJ_TIP_PAIRS])

    fist = np.mean(1.0 - e)
    like = 0.55 * thumb + 0.45 * np.mean(1.0 - e[1:])
    one = 0.60 * index + 0.40 * np.mean([1.0 - thumb, 1.0 - middle, 1.0 - ring, 1.0 - pinky])
    palm = 0.75 * np.mean(e) + 0.25 * np.tanh(spread)
    ok = 0.55 * np.exp(-pinch * 1.8) + 0.45 * np.mean(e[2:])
    return np.asarray([0.0, fist, like, ok, one, palm], dtype=np.float32)


def geometry_features(lm):
    nlm = normalize_lm(lm)
    xy = nlm[:, :2]
    center = (xy[0] + xy[5] + xy[17]) / 3.0
    feats = [nlm.reshape(-1)]

    for i, j in HAND_EDGES:
        v = nlm[j] - nlm[i]
        feats.append(v)
        feats.append(np.array([np.linalg.norm(v)], dtype=np.float32))
    for a, b, c in ANGLE_TRIPLETS:
        feats.append(np.array([cos_angle(nlm[a], nlm[b], nlm[c])], dtype=np.float32))
    for t in TIPS:
        feats.append(np.array([safe_norm(xy[t] - xy[0]), safe_norm(xy[t] - center)], dtype=np.float32))
    for i, j in ADJ_TIP_PAIRS:
        feats.append(np.array([safe_norm(xy[i] - xy[j])], dtype=np.float32))

    pair_dists = []
    for a in range(len(TIPS)):
        for b in range(a + 1, len(TIPS)):
            pair_dists.append(safe_norm(xy[TIPS[a]] - xy[TIPS[b]]))
    feats.append(np.asarray(pair_dists, dtype=np.float32))

    feats.append(finger_extension_scores(nlm))
    feats.append(validity_template_scores(nlm))
    return np.concatenate(feats).astype(np.float32)


def robust_z_scores(X):
    center = np.median(X, axis=0)
    mad = np.median(np.abs(X - center), axis=0)
    scale = 1.4826 * mad + 1e-4
    z = np.abs((X - center) / scale)
    # Use high percentile instead of max so one unstable feature cannot dominate.
    return np.percentile(z, 90, axis=1).astype(np.float32)


def detect_polluted(L, y, drop_rate, min_flag_score):
    features = np.stack([geometry_features(lm) for lm in L]).astype(np.float32)
    template = features[:, -6:]

    rows = []
    remove_mask = np.zeros(len(y), dtype=bool)

    for cls in TARGET_LABELS:
        idx = np.where(y == cls)[0]
        if len(idx) == 0:
            continue

        X = features[idx]
        robust_dist = robust_z_scores(X)
        own_template = template[idx, cls]
        other_template = template[idx, 1:].copy()
        other_template[:, cls - 1] = -1e9
        template_margin = own_template - other_template.max(axis=1)

        # Standardize components inside each class before combining.
        rd = (robust_dist - np.median(robust_dist)) / (np.std(robust_dist) + 1e-6)
        bad_template = (np.median(own_template) - own_template) / (np.std(own_template) + 1e-6)
        bad_margin = (np.median(template_margin) - template_margin) / (np.std(template_margin) + 1e-6)
        combined = rd + 0.75 * bad_template + 0.50 * bad_margin

        n_remove = int(round(len(idx) * drop_rate))
        if n_remove <= 0:
            continue

        order = np.argsort(-combined)
        selected_local = order[:n_remove]
        if min_flag_score > 0:
            selected_local = selected_local[combined[selected_local] >= min_flag_score]
        selected_idx = idx[selected_local]
        remove_mask[selected_idx] = True

        for local_i, global_i in zip(selected_local, selected_idx):
            rows.append({
                "index": int(global_i),
                "label": int(cls),
                "class_name": CLASS_NAMES[cls],
                "combined_score": float(combined[local_i]),
                "robust_distance": float(robust_dist[local_i]),
                "own_template": float(own_template[local_i]),
                "template_margin": float(template_margin[local_i]),
            })

        print(
            f"{CLASS_NAMES[cls]:5s}: flagged {len(selected_idx):5d} / {len(idx):5d} "
            f"({len(selected_idx) / len(idx):.2%})"
        )

    report = pd.DataFrame(rows).sort_values(["label", "combined_score"], ascending=[True, False])
    return remove_mask, report


def save_clean_npz(input_data, keep_mask, out_npz):
    payload = {}
    for key in input_data.files:
        arr = input_data[key]
        if len(arr) == len(keep_mask):
            payload[key] = arr[keep_mask]
        else:
            payload[key] = arr
    np.savez_compressed(out_npz, **payload)


def main():
    args = parse_args()
    if not (0.0 <= args.drop_rate < 0.5):
        raise ValueError("--drop-rate should be in [0, 0.5)")

    in_npz = Path(args.in_npz)
    out_npz = Path(args.out_npz)
    report_path = Path(args.report)

    data = np.load(in_npz, allow_pickle=False)
    L = data["L"].astype(np.float32)
    y = data["y"].astype(np.int64)

    print("Input:", in_npz)
    print("L:", L.shape, "y:", y.shape)
    print("Before counts:", np.bincount(y, minlength=len(CLASS_NAMES)))
    print("drop_rate per target:", args.drop_rate)

    remove_mask, report = detect_polluted(L, y, args.drop_rate, args.min_flag_score)

    # Add optional metadata after detection, so the ranking code stays independent.
    for key in ["src", "raw_class", "na_subtype"]:
        if key in data.files and len(data[key]) == len(remove_mask) and len(report) > 0:
            report[key] = data[key][report["index"].to_numpy()]

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report.to_csv(report_path, index=False, encoding="utf-8-sig")
    print("Report:", report_path, len(report))

    keep_mask = ~remove_mask
    print("Removed counts:", np.bincount(y[remove_mask], minlength=len(CLASS_NAMES)))
    print("After counts:", np.bincount(y[keep_mask], minlength=len(CLASS_NAMES)))

    if args.dry_run:
        print("dry-run: cleaned NPZ not written")
        return

    out_npz.parent.mkdir(parents=True, exist_ok=True)
    save_clean_npz(data, keep_mask, out_npz)
    print("Cleaned NPZ:", out_npz)


if __name__ == "__main__":
    main()
