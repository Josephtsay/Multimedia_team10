# Hand Gesture Submission (fine-grained landmark model)

This submission implements the required interface:

```python
def predict(cropped_img: np.ndarray, landmarks: np.ndarray) -> int
```

Class mapping (output):
- 0 = N/A
- 1 = fist
- 2 = like
- 3 = ok
- 4 = one
- 5 = palm

The model (`model/model.pth`) is a 34-way landmark classifier -- every
HaGRIDv2 category gets its own output class. `inference.py` collapses the
fine-grained prediction: if the predicted category is one of the 5 target
gestures, its label (1-5) is returned; any other predicted category (or a
prediction below the 0.50 confidence threshold) returns 0 (N/A).

The model uses the 21 hand landmarks only (`cropped_img` is unused).
All model paths are relative to `inference.py`.
