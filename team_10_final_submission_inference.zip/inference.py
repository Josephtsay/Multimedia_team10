"""inference.py — hand gesture classifier entry point (fine-grained landmark model).

Interface (called by TA's evaluation script):
    predict(cropped_img: np.ndarray, landmarks: np.ndarray) -> int
        cropped_img : RGB uint8 array, hand crop from MediaPipe (unused — this
                      model classifies from hand landmarks only)
        landmarks   : (21, 2) float32, crop-relative x/y from MediaPipe
        returns     : int in {0,1,2,3,4,5}
                      0=N/A, 1=fist, 2=like, 3=ok, 4=one, 5=palm

Unlike submission/landmark_only, this model was trained to recognize ALL 34
HaGRIDv2 categories individually (one output per category, including
'no_gesture', 'mute', 'stop', 'grabbing', etc. -- not just the 5 targets +
collapsed N/A). The fine-grained prediction is collapsed AFTER inference:
a predicted category that is one of the 5 target gestures maps to its
1-5 label, every other predicted category maps to 0 (N/A). The confidence
threshold is applied on top of the (uncollapsed) softmax max-probability,
exactly like submission/landmark_only/inference.py.
"""

from __future__ import annotations

import pathlib
import numpy as np
import torch
import torch.nn as nn

# ── paths ──────────────────────────────────────────────────────────────────────
_HERE      = pathlib.Path(__file__).parent
_CKPT_PATH = _HERE / 'model' / 'model.pth'
_DEVICE    = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# ── constants ──────────────────────────────────────────────────────────────────
CONFIDENCE_THRESHOLD = 0.50   # tuned on held-out test split (+1/-2 scoring)
_LM_INPUT_DIM        = 66     # 42 normalised coords + 15 angles + 9 distances

# 5 target gestures -> output labels 1-5 (0 is reserved for N/A)
_TARGET_CATEGORIES = ['fist', 'like', 'ok', 'one', 'palm']
_TARGET_TO_LABEL = {name: i + 1 for i, name in enumerate(_TARGET_CATEGORIES)}

# ── finger chains for joint-angle features ────────────────────────────────────
_FINGER_CHAINS = [
    [0, 1, 2, 3, 4],
    [0, 5, 6, 7, 8],
    [0, 9, 10, 11, 12],
    [0, 13, 14, 15, 16],
    [0, 17, 18, 19, 20],
]


# ── landmark preprocessing ────────────────────────────────────────────────────
def _preprocess_landmarks(landmarks: np.ndarray) -> np.ndarray:
    """
    landmarks: (21, 2) crop-relative x/y from MediaPipe
    returns  : (66,) float32 feature vector
    """
    lm = landmarks.reshape(21, 2).astype(np.float32).copy()

    # wrist-centred normalisation
    wrist = lm[0].copy()
    lm   -= wrist
    scale = float(np.linalg.norm(lm[9])) + 1e-6
    lm   /= scale

    # joint-angle cosines (15 values)
    angle_feats: list[float] = []
    for chain in _FINGER_CHAINS:
        for i in range(1, len(chain) - 1):
            v1    = lm[chain[i - 1]] - lm[chain[i]]
            v2    = lm[chain[i + 1]] - lm[chain[i]]
            cos_a = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-6)
            angle_feats.append(float(cos_a))

    # fingertip-to-wrist distances (5 values)
    dist_feats = [float(np.linalg.norm(lm[t])) for t in [4, 8, 12, 16, 20]]
    # thumb-tip to other fingertips (4 values)
    for t in [8, 12, 16, 20]:
        dist_feats.append(float(np.linalg.norm(lm[4] - lm[t])))

    return np.concatenate([lm.flatten(), angle_feats, dist_feats]).astype(np.float32)


# ── model definition (LandmarkOnlyModel, see models.py) ───────────────────────
class _LandmarkOnlyModel(nn.Module):
    def __init__(self, input_dim: int, num_classes: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(256, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(128, 64), nn.BatchNorm1d(64), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(64, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ── load model once at import time ────────────────────────────────────────────
_ckpt           = torch.load(_CKPT_PATH, map_location=_DEVICE, weights_only=True)
_all_categories = _ckpt['all_categories']  # fine-grained class names, in output order
_model = _LandmarkOnlyModel(input_dim=_LM_INPUT_DIM, num_classes=len(_all_categories))
_model.load_state_dict(_ckpt['model_state'])
_model.to(_DEVICE)
_model.eval()

# precompute fine-grained index -> collapsed 1-5 label (or None if not a target)
_collapse_label = [_TARGET_TO_LABEL.get(cat) for cat in _all_categories]


# ── public interface ──────────────────────────────────────────────────────────
def predict(cropped_img: np.ndarray, landmarks: np.ndarray) -> int:
    """
    cropped_img : (H, W, 3) uint8 RGB (unused — landmark-only model)
    landmarks   : (21, 2) float32 crop-relative x/y
    returns     : class index {0=N/A, 1=fist, 2=like, 3=ok, 4=one, 5=palm}
    """
    lm_feat = _preprocess_landmarks(landmarks)
    lm_t    = torch.tensor(lm_feat, dtype=torch.float32).unsqueeze(0).to(_DEVICE)  # (1,66)

    with torch.no_grad():
        probs = torch.softmax(_model(lm_t), dim=-1)  # (1, num_categories)
        max_prob, pred = probs[0].max(dim=-1)

    if max_prob.item() < CONFIDENCE_THRESHOLD:
        return 0  # N/A

    label = _collapse_label[int(pred.item())]
    return label if label is not None else 0
